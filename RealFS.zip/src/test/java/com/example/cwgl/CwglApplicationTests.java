package com.example.cwgl;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CwglApplicationTests {



}
